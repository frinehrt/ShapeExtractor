﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Compression;

using System.Threading.Tasks;
using Shared;

namespace ShapeExtractor
{
    public class ShapeExtractor
    {
        private clsShapeRepository _Repository = null;
        private clsZipFileInfo _ZipFileInfo = null;

        public clsShapeRepository Repository
        {
            get
            {
                return _Repository;
            }
        }

        public clsZipFileInfo ShapeZipFile
        {
            get
            {
                return _ZipFileInfo;
            }
        }

        public ShapeExtractor(string PathName)
        {
            if (File.Exists(PathName))
            {
                _ZipFileInfo = new clsZipFileInfo(PathName);
            }
            else
            {
                if (Directory.Exists(PathName))
                {
                    _Repository = new clsShapeRepository(PathName);
                }
                else
                {
                    return;
                }
            }            
        }



    }


}
